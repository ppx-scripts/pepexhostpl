import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Server, Shield, Clock, Zap, MapPin, Users } from "lucide-react"
import Image from "next/image"

export default function WhyUsSection() {
  return (
    <section className="bg-muted py-12 md:py-16 lg:py-20">
      <div className="container space-y-12">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Dlaczego My?
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Co nas wyróżnia?</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Wybierając PepexHost.pl, wybierasz jakość, niezawodność i profesjonalne wsparcie.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Server className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Własne Maszyny</h3>
              <p className="text-muted-foreground">
                Korzystamy z własnych serwerów wyposażonych w najnowsze procesory i szybkie dyski NVMe SSD, co
                gwarantuje najwyższą wydajność.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <MapPin className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Strategiczne Lokalizacje</h3>
              <p className="text-muted-foreground">
                Nasze serwery znajdują się w strategicznych lokalizacjach w Polsce, Niemczech i Holandii, co zapewnia
                niskie opóźnienia dla graczy z całej Europy.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Shield className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Zaawansowana Ochrona</h3>
              <p className="text-muted-foreground">
                Wszystkie nasze serwery są chronione przed atakami DDoS, co zapewnia stabilność i ciągłość działania
                Twojego serwera.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Zap className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Wsparcie dla Modów</h3>
              <p className="text-muted-foreground">
                Pełne wsparcie dla wszystkich popularnych silników: Spigot, Paper, Forge, Fabric i wielu innych.
                Zainstaluj swoje ulubione mody i pluginy.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Clock className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Wsparcie 24/7</h3>
              <p className="text-muted-foreground">
                Nasz zespół wsparcia technicznego jest dostępny 24/7, aby pomóc Ci w rozwiązaniu każdego problemu z
                Twoim serwerem.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Users className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Społeczność</h3>
              <p className="text-muted-foreground">
                Dołącz do naszej społeczności na Discordzie, gdzie możesz uzyskać pomoc, podzielić się swoimi
                doświadczeniami i poznać innych graczy.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          <div className="flex flex-col justify-center space-y-4">
            <h3 className="text-2xl font-bold">Najnowocześniejsza Infrastruktura</h3>
            <p className="text-muted-foreground">
              Nasze serwery są wyposażone w najnowsze procesory Intel i AMD, szybkie dyski NVMe SSD i dużą ilość pamięci
              RAM, co zapewnia płynne działanie nawet najbardziej wymagających serwerów Minecraft.
            </p>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <Server className="h-5 w-5 text-primary" />
                <span>Procesory Intel Xeon i AMD EPYC</span>
              </li>
              <li className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                <span>Dyski NVMe SSD</span>
              </li>
              <li className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                <span>Ochrona AntyDDoS</span>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                <span>Uptime 99.9%</span>
              </li>
            </ul>
          </div>
          <div className="rounded-lg border bg-card p-2 shadow-sm">
            <Image
              src="/server-infrastructure.png"
              alt="Infrastruktura Serwerowa"
              width={800}
              height={600}
              className="rounded-md object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
