import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Twitter, Instagram, Youtube, DiscIcon as Discord } from "lucide-react"
import Image from "next/image"

export default function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-12 md:py-16 lg:py-20">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="relative h-8 w-8">
                <Image src="/logo.png" alt="PepexHost Logo" width={32} height={32} className="object-contain" />
              </div>
              <span className="font-bold">PepexHost.pl</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Profesjonalny hosting serwerów Minecraft. Szybkie serwery, ochrona DDoS, wsparcie 24/7.
            </p>
            <div className="flex gap-4">
              <Link href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                <Facebook className="h-5 w-5 text-muted-foreground hover:text-primary" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                <Twitter className="h-5 w-5 text-muted-foreground hover:text-primary" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                <Instagram className="h-5 w-5 text-muted-foreground hover:text-primary" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="https://youtube.com" target="_blank" rel="noopener noreferrer">
                <Youtube className="h-5 w-5 text-muted-foreground hover:text-primary" />
                <span className="sr-only">YouTube</span>
              </Link>
              <Link href="https://discord.gg" target="_blank" rel="noopener noreferrer">
                <Discord className="h-5 w-5 text-muted-foreground hover:text-primary" />
                <span className="sr-only">Discord</span>
              </Link>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold">Usługi</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/oferta" className="text-muted-foreground hover:text-primary">
                  Hosting Minecraft
                </Link>
              </li>
              <li>
                <Link href="/oferta/modpacks" className="text-muted-foreground hover:text-primary">
                  Serwery Modowane
                </Link>
              </li>
              <li>
                <Link href="/oferta/premium" className="text-muted-foreground hover:text-primary">
                  Serwery Premium
                </Link>
              </li>
              <li>
                <Link href="/oferta/vps" className="text-muted-foreground hover:text-primary">
                  Serwery VPS
                </Link>
              </li>
              <li>
                <Link href="/oferta/domeny" className="text-muted-foreground hover:text-primary">
                  Domeny
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold">Informacje</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/o-nas" className="text-muted-foreground hover:text-primary">
                  O Nas
                </Link>
              </li>
              <li>
                <Link href="/kontakt" className="text-muted-foreground hover:text-primary">
                  Kontakt
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/status" className="text-muted-foreground hover:text-primary">
                  Status Usług
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-primary">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold">Newsletter</h3>
            <p className="text-sm text-muted-foreground">
              Zapisz się, aby otrzymywać informacje o promocjach i nowościach.
            </p>
            <form className="flex flex-col gap-2">
              <Input type="email" placeholder="Twój adres email" />
              <Button type="submit">Zapisz się</Button>
            </form>
          </div>
        </div>

        <div className="mt-12 border-t pt-6 text-center text-sm text-muted-foreground">
          <div className="mb-4 flex flex-wrap justify-center gap-4">
            <Link href="/regulamin" className="hover:text-primary">
              Regulamin
            </Link>
            <Link href="/polityka-prywatnosci" className="hover:text-primary">
              Polityka Prywatności
            </Link>
            <Link href="/polityka-cookies" className="hover:text-primary">
              Polityka Cookies
            </Link>
            <Link href="/zwroty" className="hover:text-primary">
              Polityka Zwrotów
            </Link>
          </div>
          <p>&copy; {new Date().getFullYear()} PepexHost.pl. Wszelkie prawa zastrzeżone.</p>
        </div>
      </div>
    </footer>
  )
}
