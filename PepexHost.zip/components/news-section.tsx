import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CalendarIcon } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function NewsSection() {
  const news = [
    {
      title: "Nowe plany hostingowe już dostępne!",
      excerpt:
        "Wprowadziliśmy nowe plany hostingowe z większą ilością RAM i lepszą ochroną DDoS. Sprawdź naszą ofertę!",
      date: "2025-05-15",
      image: "/blog-1.png",
      category: "Nowości",
      slug: "nowe-plany-hostingowe",
    },
    {
      title: "Aktualizacja panelu Pterodactyl",
      excerpt:
        "Zaktualizowaliśmy nasz panel administracyjny do najnowszej wersji, która wprowadza wiele nowych funkcji i usprawnień.",
      date: "2025-05-10",
      image: "/blog-2.png",
      category: "Aktualizacje",
      slug: "aktualizacja-panelu",
    },
    {
      title: "Poradnik: Jak zoptymalizować serwer Minecraft",
      excerpt: "Przygotowaliśmy poradnik, który pomoże Ci zoptymalizować serwer Minecraft i zwiększyć jego wydajność.",
      date: "2025-05-05",
      image: "/blog-3.png",
      category: "Poradniki",
      slug: "optymalizacja-serwera",
    },
  ]

  return (
    <section className="container space-y-12 py-12 md:py-16 lg:py-20">
      <div className="text-center">
        <Badge variant="outline" className="mb-2">
          Blog i Aktualności
        </Badge>
        <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Najnowsze Informacje</h2>
        <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
          Bądź na bieżąco z nowościami, aktualizacjami i poradnikami dotyczącymi hostingu Minecraft.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {news.map((item, index) => (
          <Card key={index} className="overflow-hidden">
            <div className="relative aspect-video overflow-hidden">
              <Image
                src={item.image || "/placeholder.svg"}
                alt={item.title}
                width={600}
                height={400}
                className="object-cover transition-transform hover:scale-105"
              />
              <div className="absolute right-2 top-2">
                <Badge>{item.category}</Badge>
              </div>
            </div>
            <CardHeader>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CalendarIcon className="h-4 w-4" />
                <time dateTime={item.date}>
                  {new Date(item.date).toLocaleDateString("pl-PL", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </time>
              </div>
              <CardTitle className="line-clamp-2">{item.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="line-clamp-3 text-muted-foreground">{item.excerpt}</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" asChild>
                <Link href={`/blog/${item.slug}`}>Czytaj więcej</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="text-center">
        <Button size="lg" asChild>
          <Link href="/blog">Zobacz Wszystkie Wpisy</Link>
        </Button>
      </div>
    </section>
  )
}
