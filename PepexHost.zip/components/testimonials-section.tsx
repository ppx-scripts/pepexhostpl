import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { StarIcon } from "lucide-react"
import Image from "next/image"

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: "Michał Kowalski",
      role: "Właściciel SurvivalMC",
      content:
        "Korzystam z usług PepexHost od ponad roku i jestem bardzo zadowolony. Serwer działa stabilnie, wsparcie techniczne jest szybkie i pomocne. Polecam!",
      rating: 5,
      avatar: "/avatar-1.png",
    },
    {
      name: "Anna Nowak",
      role: "Administrator PixelCraft",
      content:
        "Najlepszy hosting Minecraft z jakim miałam do czynienia. Szybkie serwery, intuicyjny panel i świetne wsparcie techniczne. Zdecydowanie polecam!",
      rating: 5,
      avatar: "/avatar-2.png",
    },
    {
      name: "Piotr Wiśniewski",
      role: "Właściciel NetworkPL",
      content:
        "Po wielu próbach z różnymi hostingami, w końcu znalazłem PepexHost. Serwery są szybkie, stabilne i nigdy nie miałem problemów z atakami DDoS.",
      rating: 5,
      avatar: "/avatar-3.png",
    },
    {
      name: "Karolina Lewandowska",
      role: "YouTuber",
      content:
        "Prowadzę serwer dla mojej społeczności z YouTube i PepexHost spełnia wszystkie moje oczekiwania. Świetna wydajność i niezawodność.",
      rating: 4,
      avatar: "/avatar-4.png",
    },
    {
      name: "Tomasz Zieliński",
      role: "Developer ModpackMC",
      content:
        "Jako developer modpacków potrzebuję niezawodnego hostingu, który poradzi sobie z dużą ilością modów. PepexHost sprawdza się doskonale!",
      rating: 5,
      avatar: "/avatar-5.png",
    },
    {
      name: "Marta Dąbrowska",
      role: "Administrator MiniGamesMC",
      content:
        "Hosting idealny dla serwerów z minigierkami. Stabilny, szybki i z dobrym wsparciem technicznym. Polecam każdemu!",
      rating: 5,
      avatar: "/avatar-6.png",
    },
  ]

  return (
    <section className="container space-y-12 py-12 md:py-16 lg:py-20">
      <div className="text-center">
        <Badge variant="outline" className="mb-2">
          Opinie Klientów
        </Badge>
        <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Co mówią nasi klienci?</h2>
        <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
          Sprawdź, co mówią o nas właściciele serwerów Minecraft, którzy korzystają z naszych usług.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {testimonials.map((testimonial, index) => (
          <Card key={index} className="overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="relative h-12 w-12 overflow-hidden rounded-full">
                  <Image
                    src={testimonial.avatar || "/placeholder.svg"}
                    alt={testimonial.name}
                    width={48}
                    height={48}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-bold">{testimonial.name}</h3>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
              <div className="mt-4 flex">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <StarIcon key={i} className="h-5 w-5 fill-primary text-primary" />
                ))}
                {Array.from({ length: 5 - testimonial.rating }).map((_, i) => (
                  <StarIcon key={i} className="h-5 w-5 text-muted-foreground" />
                ))}
              </div>
              <p className="mt-4 text-muted-foreground">{testimonial.content}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
