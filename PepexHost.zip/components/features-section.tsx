import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Server, Clock, Zap, HardDrive, Cpu, Database, Cloud } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function FeaturesSection() {
  return (
    <section className="container space-y-12 py-12 md:py-16 lg:py-20">
      <div className="text-center">
        <Badge variant="outline" className="mb-2">
          Funkcje Hostingu
        </Badge>
        <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Wszystko, czego potrzebujesz</h2>
        <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
          Nasz hosting Minecraft oferuje zaawansowane funkcje, które pomogą Ci w zarządzaniu serwerem.
        </p>
      </div>

      <Tabs defaultValue="panel" className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="panel">Panel</TabsTrigger>
          <TabsTrigger value="backups">Kopie Zapasowe</TabsTrigger>
          <TabsTrigger value="plugins">Pluginy</TabsTrigger>
          <TabsTrigger value="versions">Wersje MC</TabsTrigger>
          <TabsTrigger value="scheduler">Harmonogram</TabsTrigger>
          <TabsTrigger value="discord">Discord</TabsTrigger>
        </TabsList>

        <TabsContent value="panel" className="mt-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <h3 className="text-2xl font-bold">Panel Pterodactyl</h3>
              <p className="text-muted-foreground">
                Nowoczesny panel zarządzania serwerem z intuicyjnym interfejsem. Pełna kontrola nad serwerem, dostęp do
                konsoli, zarządzanie plikami i wiele więcej.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-primary" />
                  <span>Dostęp do konsoli serwera</span>
                </li>
                <li className="flex items-center gap-2">
                  <HardDrive className="h-5 w-5 text-primary" />
                  <span>Zarządzanie plikami przez przeglądarkę</span>
                </li>
                <li className="flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-primary" />
                  <span>Monitorowanie zasobów w czasie rzeczywistym</span>
                </li>
                <li className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-primary" />
                  <span>Łatwa instalacja pluginów i modów</span>
                </li>
              </ul>
            </div>
            <div className="rounded-lg border bg-card p-2 shadow-sm">
              <Image
                src="/panel-dashboard.png"
                alt="Panel Pterodactyl"
                width={800}
                height={600}
                className="rounded-md object-cover"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="backups" className="mt-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <h3 className="text-2xl font-bold">Automatyczne Kopie Zapasowe</h3>
              <p className="text-muted-foreground">
                Twój serwer jest zawsze bezpieczny dzięki automatycznym kopiom zapasowym. Możesz łatwo przywrócić serwer
                do wcześniejszego stanu w przypadku problemów.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <span>Harmonogram kopii zapasowych</span>
                </li>
                <li className="flex items-center gap-2">
                  <Cloud className="h-5 w-5 text-primary" />
                  <span>Przechowywanie w bezpiecznej lokalizacji</span>
                </li>
                <li className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <span>Szybkie przywracanie</span>
                </li>
              </ul>
            </div>
            <div className="rounded-lg border bg-card p-2 shadow-sm">
              <Image
                src="/minecraft-backups.png"
                alt="Kopie Zapasowe"
                width={800}
                height={600}
                className="rounded-md object-cover"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="plugins" className="mt-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <h3 className="text-2xl font-bold">Obsługa Pluginów i Modów</h3>
              <p className="text-muted-foreground">
                Łatwa instalacja i zarządzanie pluginami oraz modami. Wspieramy wszystkie popularne silniki: Spigot,
                Paper, Forge, Fabric i wiele innych.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-primary" />
                  <span>Wsparcie dla Spigot, Paper, Forge, Fabric</span>
                </li>
                <li className="flex items-center gap-2">
                  <HardDrive className="h-5 w-5 text-primary" />
                  <span>Instalacja jednym kliknięciem</span>
                </li>
                <li className="flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-primary" />
                  <span>Automatyczne aktualizacje</span>
                </li>
              </ul>
            </div>
            <div className="rounded-lg border bg-card p-2 shadow-sm">
              <Image
                src="/minecraft-plugins.png"
                alt="Pluginy i Mody"
                width={800}
                height={600}
                className="rounded-md object-cover"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="versions" className="mt-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <h3 className="text-2xl font-bold">Wszystkie Wersje Minecraft</h3>
              <p className="text-muted-foreground">
                Wspieramy wszystkie wersje Minecraft od 1.7 do najnowszych. Możesz łatwo przełączać się między wersjami
                w panelu administracyjnym.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-primary" />
                  <span>Wsparcie dla wszystkich wersji od 1.7+</span>
                </li>
                <li className="flex items-center gap-2">
                  <HardDrive className="h-5 w-5 text-primary" />
                  <span>Łatwa zmiana wersji</span>
                </li>
                <li className="flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-primary" />
                  <span>Snapshoty i wersje eksperymentalne</span>
                </li>
              </ul>
            </div>
            <div className="rounded-lg border bg-card p-2 shadow-sm">
              <Image
                src="/minecraft-versions.png"
                alt="Wersje Minecraft"
                width={800}
                height={600}
                className="rounded-md object-cover"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="scheduler" className="mt-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <h3 className="text-2xl font-bold">Harmonogram Zadań</h3>
              <p className="text-muted-foreground">
                Automatyzuj zadania na swoim serwerze. Ustaw automatyczne restarty, kopie zapasowe, ogłoszenia i wiele
                więcej.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <span>Automatyczne restarty</span>
                </li>
                <li className="flex items-center gap-2">
                  <Cloud className="h-5 w-5 text-primary" />
                  <span>Zaplanowane kopie zapasowe</span>
                </li>
                <li className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <span>Cykliczne ogłoszenia</span>
                </li>
              </ul>
            </div>
            <div className="rounded-lg border bg-card p-2 shadow-sm">
              <Image
                src="/minecraft-scheduler.png"
                alt="Harmonogram Zadań"
                width={800}
                height={600}
                className="rounded-md object-cover"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="discord" className="mt-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <h3 className="text-2xl font-bold">Integracja z Discord</h3>
              <p className="text-muted-foreground">
                Połącz swój serwer Minecraft z Discordem. Otrzymuj powiadomienia o ważnych wydarzeniach, monitoruj
                status serwera i więcej.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-primary" />
                  <span>Powiadomienia o statusie serwera</span>
                </li>
                <li className="flex items-center gap-2">
                  <HardDrive className="h-5 w-5 text-primary" />
                  <span>Czat między Minecraft a Discord</span>
                </li>
                <li className="flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-primary" />
                  <span>Komendy z poziomu Discorda</span>
                </li>
              </ul>
            </div>
            <div className="rounded-lg border bg-card p-2 shadow-sm">
              <Image
                src="/minecraft-discord.png"
                alt="Integracja z Discord"
                width={800}
                height={600}
                className="rounded-md object-cover"
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <div className="text-center">
        <Button size="lg" asChild>
          <Link href="/funkcje">Zobacz Wszystkie Funkcje</Link>
        </Button>
      </div>
    </section>
  )
}
