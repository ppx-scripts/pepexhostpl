import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 to-background pt-16 md:pt-24">
      <div className="container relative z-10 flex flex-col items-center justify-center gap-4 text-center">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
            Twój serwer. <span className="text-primary">Nasza moc.</span>
          </h1>
          <p className="mx-auto max-w-[700px] text-lg text-muted-foreground md:text-xl">
            Profesjonalny hosting serwerów Minecraft z najnowszymi technologiami, ochroną DDoS i wsparciem 24/7.
          </p>
        </div>
        <div className="flex flex-col gap-2 min-[400px]:flex-row">
          <Button size="lg" asChild>
            <Link href="/zamow">Zamów Serwer</Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link href="/oferta">Sprawdź Ofertę</Link>
          </Button>
        </div>

        <div className="relative mt-8 w-full max-w-5xl">
          <div className="aspect-[16/9] overflow-hidden rounded-t-xl border-2 border-primary/20 bg-background shadow-xl">
            <Image
              src="/hero-minecraft.png"
              alt="Minecraft Server"
              width={1920}
              height={1080}
              className="h-full w-full object-cover"
              priority
            />
          </div>
          <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
            Uruchom swój serwer w mniej niż 60 sekund!
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute left-0 top-1/2 h-[300px] w-[300px] -translate-y-1/2 rounded-full bg-primary/20 blur-3xl"></div>
      <div className="absolute right-0 top-1/3 h-[250px] w-[250px] rounded-full bg-primary/20 blur-3xl"></div>
    </section>
  )
}
