import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Mail, Phone, MapPin, MessageSquare, Clock } from "lucide-react"
import Link from "next/link"

export default function KontaktPage() {
  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Kontakt
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Skontaktuj się z nami</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Masz pytania? Potrzebujesz pomocy? Skontaktuj się z nami, a nasz zespół odpowie na wszystkie Twoje pytania.
          </p>
        </div>

        <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Formularz kontaktowy</CardTitle>
              <CardDescription>Wypełnij formularz, a odpowiemy najszybciej jak to możliwe.</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label
                      htmlFor="name"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Imię i nazwisko
                    </label>
                    <Input id="name" placeholder="Jan Kowalski" />
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="email"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Email
                    </label>
                    <Input id="email" type="email" placeholder="jan@example.com" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label
                    htmlFor="subject"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Temat
                  </label>
                  <Input id="subject" placeholder="Temat wiadomości" />
                </div>
                <div className="space-y-2">
                  <label
                    htmlFor="message"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Wiadomość
                  </label>
                  <Textarea id="message" placeholder="Twoja wiadomość" className="min-h-[150px]" />
                </div>
                <Button type="submit" className="w-full">
                  Wyślij wiadomość
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informacje kontaktowe</CardTitle>
                <CardDescription>Skontaktuj się z nami bezpośrednio.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-4">
                  <Mail className="h-5 w-5 text-primary" />
                  <div>
                    <h3 className="font-medium">Email</h3>
                    <p className="text-sm text-muted-foreground">kontakt@pepexhost.pl</p>
                    <p className="text-sm text-muted-foreground">pomoc@pepexhost.pl (wsparcie techniczne)</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Phone className="h-5 w-5 text-primary" />
                  <div>
                    <h3 className="font-medium">Telefon</h3>
                    <p className="text-sm text-muted-foreground">+48 123 456 789</p>
                    <p className="text-sm text-muted-foreground">Pon-Pt: 9:00 - 17:00</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <MapPin className="h-5 w-5 text-primary" />
                  <div>
                    <h3 className="font-medium">Adres</h3>
                    <p className="text-sm text-muted-foreground">ul. Przykładowa 123</p>
                    <p className="text-sm text-muted-foreground">00-000 Warszawa, Polska</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Wsparcie techniczne</CardTitle>
                <CardDescription>Potrzebujesz pomocy technicznej?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-4">
                  <MessageSquare className="h-5 w-5 text-primary" />
                  <div>
                    <h3 className="font-medium">Discord</h3>
                    <p className="text-sm text-muted-foreground">
                      Dołącz do naszego serwera Discord, gdzie możesz uzyskać szybką pomoc od naszego zespołu i
                      społeczności.
                    </p>
                    <Button variant="outline" size="sm" className="mt-2" asChild>
                      <Link href="https://discord.gg/pepexhost" target="_blank" rel="noopener noreferrer">
                        Dołącz do Discord
                      </Link>
                    </Button>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Clock className="h-5 w-5 text-primary" />
                  <div>
                    <h3 className="font-medium">Godziny wsparcia</h3>
                    <p className="text-sm text-muted-foreground">
                      Nasze wsparcie techniczne jest dostępne 24/7 dla wszystkich klientów.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>FAQ</CardTitle>
                <CardDescription>Często zadawane pytania</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Sprawdź naszą bazę wiedzy, gdzie znajdziesz odpowiedzi na najczęściej zadawane pytania.
                </p>
                <Button variant="outline" className="mt-4 w-full" asChild>
                  <Link href="/faq">Przejdź do FAQ</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Mapa
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Nasza lokalizacja</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Znajdź nas na mapie. Możesz odwiedzić nas osobiście w godzinach pracy biura.
          </p>
        </div>

        <div className="mx-auto max-w-6xl overflow-hidden rounded-lg border">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d156388.35438500392!2d20.92111271640625!3d52.233065000000006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471ecc669a869f01%3A0x72f0be2a88ead3fc!2sWarszawa!5e0!3m2!1spl!2spl!4v1621436361526!5m2!1spl!2spl"
            width="100%"
            height="450"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </section>
    </div>
  )
}
