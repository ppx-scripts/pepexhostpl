import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, Server, Shield, Clock, Zap } from "lucide-react"
import Link from "next/link"
import HeroSection from "@/components/hero-section"
import FeaturesSection from "@/components/features-section"
import TestimonialsSection from "@/components/testimonials-section"
import WhyUsSection from "@/components/why-us-section"
import NewsSection from "@/components/news-section"

export default function Home() {
  return (
    <div className="flex flex-col gap-16 pb-16">
      <HeroSection />

      {/* Quick Features */}
      <section className="container grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-2 border-primary/20">
          <CardContent className="flex flex-col items-center gap-2 p-6">
            <Server className="h-10 w-10 text-primary" />
            <h3 className="text-xl font-bold">Wydajne Serwery</h3>
            <p className="text-center text-muted-foreground">Najnowsze procesory i szybkie dyski NVMe SSD</p>
          </CardContent>
        </Card>
        <Card className="border-2 border-primary/20">
          <CardContent className="flex flex-col items-center gap-2 p-6">
            <Shield className="h-10 w-10 text-primary" />
            <h3 className="text-xl font-bold">Ochrona DDoS</h3>
            <p className="text-center text-muted-foreground">Zaawansowana ochrona przed atakami DDoS</p>
          </CardContent>
        </Card>
        <Card className="border-2 border-primary/20">
          <CardContent className="flex flex-col items-center gap-2 p-6">
            <Clock className="h-10 w-10 text-primary" />
            <h3 className="text-xl font-bold">Wsparcie 24/7</h3>
            <p className="text-center text-muted-foreground">Pomoc techniczna dostępna przez całą dobę</p>
          </CardContent>
        </Card>
        <Card className="border-2 border-primary/20">
          <CardContent className="flex flex-col items-center gap-2 p-6">
            <Zap className="h-10 w-10 text-primary" />
            <h3 className="text-xl font-bold">99.9% Uptime</h3>
            <p className="text-center text-muted-foreground">Gwarantowana dostępność serwerów</p>
          </CardContent>
        </Card>
      </section>

      {/* Popular Plans */}
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Popularne Pakiety
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Wybierz Idealny Plan</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Oferujemy różne pakiety hostingowe dopasowane do Twoich potrzeb. Od małych serwerów dla przyjaciół po duże
            projekty.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
          {/* Basic Plan */}
          <Card className="flex flex-col border-2">
            <CardContent className="flex flex-1 flex-col p-6">
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Basic</h3>
                <p className="text-sm text-muted-foreground">Idealny dla małych serwerów</p>
              </div>
              <div className="mt-6 space-y-4">
                <div className="text-3xl font-bold">
                  9.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>2GB RAM</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>10 Slotów</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Podstawowa ochrona DDoS</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Lokalizacja: Polska</span>
                  </li>
                </ul>
              </div>
              <div className="mt-auto pt-6">
                <Button className="w-full" asChild>
                  <Link href="/zamow">Zamów Teraz</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Standard Plan */}
          <Card className="flex flex-col border-2">
            <CardContent className="flex flex-1 flex-col p-6">
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Standard</h3>
                <p className="text-sm text-muted-foreground">Dla średnich serwerów</p>
              </div>
              <div className="mt-6 space-y-4">
                <div className="text-3xl font-bold">
                  19.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>4GB RAM</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>20 Slotów</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Zaawansowana ochrona DDoS</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Lokalizacja: PL/DE</span>
                  </li>
                </ul>
              </div>
              <div className="mt-auto pt-6">
                <Button className="w-full" asChild>
                  <Link href="/zamow">Zamów Teraz</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Premium Plan - Highlighted */}
          <Card className="flex flex-col border-2 border-primary relative">
            <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
              Polecany
            </div>
            <CardContent className="flex flex-1 flex-col p-6">
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Premium</h3>
                <p className="text-sm text-muted-foreground">Dla dużych serwerów</p>
              </div>
              <div className="mt-6 space-y-4">
                <div className="text-3xl font-bold">
                  29.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>8GB RAM</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>40 Slotów</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Premium ochrona DDoS</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Lokalizacja: PL/DE/NL</span>
                  </li>
                </ul>
              </div>
              <div className="mt-auto pt-6">
                <Button className="w-full" asChild>
                  <Link href="/zamow">Zamów Teraz</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Ultimate Plan */}
          <Card className="flex flex-col border-2">
            <CardContent className="flex flex-1 flex-col p-6">
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Ultimate</h3>
                <p className="text-sm text-muted-foreground">Dla profesjonalnych projektów</p>
              </div>
              <div className="mt-6 space-y-4">
                <div className="text-3xl font-bold">
                  49.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>16GB RAM</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Bez limitu slotów</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Enterprise ochrona DDoS</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                    <span>Dedykowane zasoby CPU</span>
                  </li>
                </ul>
              </div>
              <div className="mt-auto pt-6">
                <Button className="w-full" asChild>
                  <Link href="/zamow">Zamów Teraz</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <Button size="lg" variant="outline" asChild>
            <Link href="/oferta">Zobacz Wszystkie Plany</Link>
          </Button>
        </div>
      </section>

      <WhyUsSection />
      <FeaturesSection />
      <TestimonialsSection />
      <NewsSection />

      {/* CTA Section */}
      <section className="bg-primary text-primary-foreground">
        <div className="container py-12 md:py-16 lg:py-20">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
              Gotowy na własny serwer Minecraft?
            </h2>
            <p className="mt-4 text-lg md:text-xl">
              Dołącz do tysięcy zadowolonych klientów i uruchom swój serwer już dziś!
            </p>
            <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/oferta">Zobacz Ofertę</Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent" asChild>
                <Link href="/kontakt">Skontaktuj się z nami</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
