import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export default function PanelPage() {
  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Panel Klienta
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Panel Klienta</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Zaloguj się do panelu klienta, aby zarządzać swoimi serwerami, fakturami i danymi konta.
          </p>
        </div>

        <div className="mx-auto max-w-md">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Logowanie</TabsTrigger>
              <TabsTrigger value="register">Rejestracja</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Logowanie</CardTitle>
                  <CardDescription>Zaloguj się do swojego konta PepexHost.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="jan@example.com" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Hasło</Label>
                      <Link href="/reset-password" className="text-xs text-primary hover:underline">
                        Zapomniałeś hasła?
                      </Link>
                    </div>
                    <Input id="password" type="password" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Zaloguj się</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Rejestracja</CardTitle>
                  <CardDescription>Utwórz nowe konto PepexHost.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="first-name">Imię</Label>
                      <Input id="first-name" placeholder="Jan" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name">Nazwisko</Label>
                      <Input id="last-name" placeholder="Kowalski" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="jan@example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Hasło</Label>
                    <Input id="password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Potwierdź hasło</Label>
                    <Input id="confirm-password" type="password" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Zarejestruj się</Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Korzyści
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Korzyści z panelu klienta</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Panel klienta PepexHost oferuje wiele funkcji, które ułatwiają zarządzanie serwerami i kontem.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">1</span>
              </div>
              <h3 className="text-xl font-bold">Zarządzanie serwerami</h3>
              <p className="text-muted-foreground">
                Zarządzaj wszystkimi swoimi serwerami z jednego miejsca. Uruchamiaj, zatrzymuj, restartuj i monitoruj
                swoje serwery.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">2</span>
              </div>
              <h3 className="text-xl font-bold">Faktury i płatności</h3>
              <p className="text-muted-foreground">
                Przeglądaj swoje faktury, dokonuj płatności i zarządzaj metodami płatności. Wszystko w jednym miejscu.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">3</span>
              </div>
              <h3 className="text-xl font-bold">Wsparcie techniczne</h3>
              <p className="text-muted-foreground">
                Otwieraj zgłoszenia wsparcia technicznego i śledź ich status. Szybka i skuteczna pomoc w razie
                problemów.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">4</span>
              </div>
              <h3 className="text-xl font-bold">Zarządzanie domenami</h3>
              <p className="text-muted-foreground">
                Zarządzaj swoimi domenami, ustawiaj rekordy DNS i konfiguruj przekierowania. Wszystko w jednym miejscu.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">5</span>
              </div>
              <h3 className="text-xl font-bold">Zarządzanie kontem</h3>
              <p className="text-muted-foreground">
                Aktualizuj swoje dane osobowe, zmieniaj hasło i zarządzaj ustawieniami bezpieczeństwa.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">6</span>
              </div>
              <h3 className="text-xl font-bold">Powiadomienia</h3>
              <p className="text-muted-foreground">
                Otrzymuj powiadomienia o ważnych wydarzeniach, takich jak wygasające usługi, problemy z serwerem i nowe
                faktury.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
