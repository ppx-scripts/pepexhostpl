import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Server, Shield, Clock, Zap, HardDrive, Cpu, Database, Cloud, Users, Globe } from "lucide-react"
import Image from "next/image"

export default function FunkcjePage() {
  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Funkcje
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Funkcje Hostingu</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Poznaj wszystkie funkcje naszego hostingu Minecraft, które pomogą Ci w zarządzaniu serwerem.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Server className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Panel Pterodactyl</h3>
              <p className="text-muted-foreground">
                Nowoczesny panel zarządzania serwerem z intuicyjnym interfejsem. Pełna kontrola nad serwerem, dostęp do
                konsoli, zarządzanie plikami i wiele więcej.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Cloud className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Automatyczne Kopie Zapasowe</h3>
              <p className="text-muted-foreground">
                Twórz automatyczne kopie zapasowe serwera według harmonogramu. Łatwo przywracaj serwer do wcześniejszego
                stanu w przypadku problemów.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Database className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Obsługa Pluginów i Modów</h3>
              <p className="text-muted-foreground">
                Łatwa instalacja i zarządzanie pluginami oraz modami. Wspieramy wszystkie popularne silniki: Spigot,
                Paper, Forge, Fabric i wiele innych.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <HardDrive className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Wszystkie Wersje Minecraft</h3>
              <p className="text-muted-foreground">
                Wspieramy wszystkie wersje Minecraft od 1.7 do najnowszych. Możesz łatwo przełączać się między wersjami
                w panelu administracyjnym.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Clock className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Harmonogram Zadań</h3>
              <p className="text-muted-foreground">
                Automatyzuj zadania na swoim serwerze. Ustaw automatyczne restarty, kopie zapasowe, ogłoszenia i wiele
                więcej.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Users className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Integracja z Discord</h3>
              <p className="text-muted-foreground">
                Połącz swój serwer Minecraft z Discordem. Otrzymuj powiadomienia o ważnych wydarzeniach, monitoruj
                status serwera i więcej.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Shield className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Ochrona DDoS</h3>
              <p className="text-muted-foreground">
                Wszystkie nasze serwery są chronione przed atakami DDoS. Używamy zaawansowanych systemów filtrowania
                ruchu, które wykrywają i blokują ataki.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Cpu className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Wydajne Serwery</h3>
              <p className="text-muted-foreground">
                Nasze serwery są wyposażone w najnowsze procesory i szybkie dyski NVMe SSD, co gwarantuje najwyższą
                wydajność.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <Globe className="h-12 w-12 text-primary" />
              <h3 className="text-xl font-bold">Własna Domena</h3>
              <p className="text-muted-foreground">
                Podłącz własną domenę do swojego serwera Minecraft. Oferujemy również subdomeny dla wszystkich planów
                hostingowych.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="bg-muted py-12 md:py-16 lg:py-20">
        <div className="container space-y-12">
          <div className="text-center">
            <Badge variant="outline" className="mb-2">
              Szczegóły Funkcji
            </Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Poznaj szczegóły</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
              Dowiedz się więcej o najważniejszych funkcjach naszego hostingu Minecraft.
            </p>
          </div>

          <Tabs defaultValue="panel" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
              <TabsTrigger value="panel">Panel</TabsTrigger>
              <TabsTrigger value="backups">Kopie Zapasowe</TabsTrigger>
              <TabsTrigger value="plugins">Pluginy i Mody</TabsTrigger>
            </TabsList>

            <TabsContent value="panel" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <h3 className="text-2xl font-bold">Panel Pterodactyl</h3>
                  <p className="text-muted-foreground">
                    Panel Pterodactyl to nowoczesny panel zarządzania serwerem Minecraft, który oferuje pełną kontrolę
                    nad serwerem. Panel jest intuicyjny i łatwy w obsłudze, a jednocześnie oferuje zaawansowane funkcje
                    dla doświadczonych administratorów.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Server className="h-5 w-5 text-primary" />
                      <span>Dostęp do konsoli serwera w czasie rzeczywistym</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <HardDrive className="h-5 w-5 text-primary" />
                      <span>Zarządzanie plikami przez przeglądarkę</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Cpu className="h-5 w-5 text-primary" />
                      <span>Monitorowanie zasobów w czasie rzeczywistym</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Database className="h-5 w-5 text-primary" />
                      <span>Łatwa instalacja pluginów i modów</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-primary" />
                      <span>Zarządzanie użytkownikami i uprawnieniami</span>
                    </li>
                  </ul>
                </div>
                <div className="rounded-lg border bg-card p-2 shadow-sm">
                  <Image
                    src="/panel-dashboard.png"
                    alt="Panel Pterodactyl"
                    width={800}
                    height={600}
                    className="rounded-md object-cover"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="backups" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <h3 className="text-2xl font-bold">Automatyczne Kopie Zapasowe</h3>
                  <p className="text-muted-foreground">
                    Nasze automatyczne kopie zapasowe zapewniają bezpieczeństwo Twoich danych. Możesz łatwo tworzyć
                    kopie zapasowe serwera według harmonogramu i przywracać je w razie potrzeby.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-primary" />
                      <span>Harmonogram kopii zapasowych (codziennie, co tydzień, co miesiąc)</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Cloud className="h-5 w-5 text-primary" />
                      <span>Przechowywanie kopii zapasowych w bezpiecznej lokalizacji</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-primary" />
                      <span>Szybkie przywracanie kopii zapasowych</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <HardDrive className="h-5 w-5 text-primary" />
                      <span>Możliwość pobrania kopii zapasowej na własny komputer</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-primary" />
                      <span>Szyfrowanie kopii zapasowych</span>
                    </li>
                  </ul>
                </div>
                <div className="rounded-lg border bg-card p-2 shadow-sm">
                  <Image
                    src="/minecraft-backups.png"
                    alt="Automatyczne Kopie Zapasowe"
                    width={800}
                    height={600}
                    className="rounded-md object-cover"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="plugins" className="mt-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
                <div className="flex flex-col justify-center space-y-4">
                  <h3 className="text-2xl font-bold">Obsługa Pluginów i Modów</h3>
                  <p className="text-muted-foreground">
                    Nasza platforma oferuje pełne wsparcie dla pluginów i modów. Możesz łatwo instalować i zarządzać
                    pluginami oraz modami dla swojego serwera Minecraft.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Server className="h-5 w-5 text-primary" />
                      <span>Wsparcie dla Spigot, Paper, Forge, Fabric i innych</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <HardDrive className="h-5 w-5 text-primary" />
                      <span>Instalacja pluginów i modów jednym kliknięciem</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Cpu className="h-5 w-5 text-primary" />
                      <span>Automatyczne aktualizacje pluginów i modów</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Database className="h-5 w-5 text-primary" />
                      <span>Zarządzanie konfiguracją pluginów</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-primary" />
                      <span>Sprawdzanie kompatybilności pluginów i modów</span>
                    </li>
                  </ul>
                </div>
                <div className="rounded-lg border bg-card p-2 shadow-sm">
                  <Image
                    src="/minecraft-plugins.png"
                    alt="Obsługa Pluginów i Modów"\
