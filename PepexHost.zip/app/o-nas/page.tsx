import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function ONasPage() {
  const teamMembers = [
    {
      name: "Adam Nowak",
      role: "CEO & Founder",
      bio: "Adam założył PepexHost w 2020 roku z pasji do gier i technologii. Ma ponad 10 lat doświadczenia w branży IT.",
      image: "/avatar-1.png",
    },
    {
      name: "Marta Kowalska",
      role: "CTO",
      bio: "Marta odpowiada za infrastrukturę techniczną PepexHost. Specjalizuje się w optymalizacji serwerów i bezpieczeństwie.",
      image: "/avatar-2.png",
    },
    {
      name: "Piotr Zieliński",
      role: "Wsparcie Techniczne",
      bio: "Piotr dba o to, aby nasi klienci otrzymywali najlepsze wsparcie techniczne. Zawsze gotowy do pomocy.",
      image: "/avatar-3.png",
    },
    {
      name: "Karolina Lewandowska",
      role: "Marketing Manager",
      bio: "Karolina odpowiada za marketing i komunikację. Dba o to, aby nasi klienci byli na bieżąco z nowościami.",
      image: "/avatar-4.png",
    },
  ]

  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            O Nas
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Kim jesteśmy?</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Poznaj historię PepexHost.pl i naszą misję dostarczania najlepszych usług hostingowych dla serwerów
            Minecraft.
          </p>
        </div>

        <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-2">
          <div className="flex flex-col justify-center space-y-4">
            <h2 className="text-2xl font-bold">Nasza historia</h2>
            <p className="text-muted-foreground">
              PepexHost.pl powstał w 2020 roku z pasji do gier i technologii. Zaczęliśmy jako mały projekt, który miał
              na celu dostarczenie niedrogiego i niezawodnego hostingu serwerów Minecraft dla polskich graczy.
            </p>
            <p className="text-muted-foreground">
              Z biegiem czasu, dzięki ciągłemu rozwojowi i inwestycjom w infrastrukturę, staliśmy się jednym z wiodących
              dostawców hostingu Minecraft w Polsce. Dziś obsługujemy tysiące serwerów i mamy klientów z całej Europy.
            </p>
            <p className="text-muted-foreground">
              Naszą misją jest dostarczanie najwyższej jakości usług hostingowych w przystępnych cenach, z naciskiem na
              wydajność, niezawodność i profesjonalne wsparcie techniczne.
            </p>
          </div>
          <div className="rounded-lg border bg-card p-2 shadow-sm">
            <Image
              src="/server-infrastructure.png"
              alt="Nasza historia"
              width={800}
              height={600}
              className="rounded-md object-cover"
            />
          </div>
        </div>
      </section>

      <section className="bg-muted py-12 md:py-16 lg:py-20">
        <div className="container space-y-12">
          <div className="text-center">
            <Badge variant="outline" className="mb-2">
              Nasze Wartości
            </Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Co nas napędza?</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
              Nasze wartości są fundamentem wszystkiego, co robimy. Kierujemy się nimi w codziennej pracy i relacjach z
              klientami.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Jakość</h3>
                <p className="text-muted-foreground">
                  Dostarczamy usługi najwyższej jakości. Inwestujemy w najnowsze technologie i ciągle doskonalimy nasze
                  rozwiązania.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Niezawodność</h3>
                <p className="text-muted-foreground">
                  Naszym priorytetem jest niezawodność. Dbamy o to, aby nasze serwery działały stabilnie i były zawsze
                  dostępne.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Wsparcie</h3>
                <p className="text-muted-foreground">
                  Oferujemy profesjonalne wsparcie techniczne 24/7. Nasz zespół jest zawsze gotowy do pomocy w
                  rozwiązaniu każdego problemu.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Innowacyjność</h3>
                <p className="text-muted-foreground">
                  Ciągle poszukujemy nowych rozwiązań i technologii, które pomogą nam dostarczać jeszcze lepsze usługi
                  dla naszych klientów.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Transparentność</h3>
                <p className="text-muted-foreground">
                  Działamy transparentnie. Informujemy o wszystkich planowanych pracach i ewentualnych problemach.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Społeczność</h3>
                <p className="text-muted-foreground">
                  Budujemy społeczność graczy i administratorów serwerów Minecraft. Wspieramy projekty społecznościowe i
                  dzielimy się wiedzą.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="container space-y-12">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Nasz Zespół
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Poznaj nasz zespół</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Za PepexHost.pl stoi zespół pasjonatów technologii i gier, którzy dbają o to, aby nasze usługi były
            najwyższej jakości.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {teamMembers.map((member, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex flex-col items-center gap-4 text-center">
                  <div className="relative h-24 w-24 overflow-hidden rounded-full">
                    <Image
                      src={member.image || "/placeholder.svg"}
                      alt={member.name}
                      width={96}
                      height={96}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{member.name}</h3>
                    <p className="text-sm text-primary">{member.role}</p>
                  </div>
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="bg-primary text-primary-foreground">
        <div className="container py-12 md:py-16 lg:py-20">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Dołącz do nas!</h2>
            <p className="mt-4 text-lg md:text-xl">
              Szukasz pracy w dynamicznym zespole pasjonatów technologii i gier? Sprawdź nasze oferty pracy!
            </p>
            <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/kariera">Sprawdź oferty pracy</Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent" asChild>
                <Link href="/kontakt">Skontaktuj się z nami</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
