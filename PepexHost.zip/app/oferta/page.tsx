import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, HelpCircle } from "lucide-react"
import Link from "next/link"

export default function OfertaPage() {
  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Oferta
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Plany Hostingowe</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Wybierz plan hostingowy, który najlepiej odpowiada Twoim potrzebom. Wszystkie plany zawierają panel
            Pterodactyl, ochronę DDoS i wsparcie techniczne 24/7.
          </p>
        </div>

        <Tabs defaultValue="minecraft" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
            <TabsTrigger value="minecraft">Minecraft</TabsTrigger>
            <TabsTrigger value="modpacks">Modpacks</TabsTrigger>
            <TabsTrigger value="vps">VPS</TabsTrigger>
          </TabsList>

          <TabsContent value="minecraft" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {/* Basic Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Basic</h3>
                    <p className="text-sm text-muted-foreground">Idealny dla małych serwerów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      9.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>2GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>10 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Podstawowa ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: Polska</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=basic">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Standard Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Standard</h3>
                    <p className="text-sm text-muted-foreground">Dla średnich serwerów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      19.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>20 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Zaawansowana ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=standard">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Premium Plan - Highlighted */}
              <Card className="flex flex-col border-2 border-primary relative">
                <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Polecany
                </div>
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Premium</h3>
                    <p className="text-sm text-muted-foreground">Dla dużych serwerów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      29.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>8GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>40 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Premium ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE/NL</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=premium">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Ultimate Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Ultimate</h3>
                    <p className="text-sm text-muted-foreground">Dla profesjonalnych projektów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      49.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>16GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Bez limitu slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Enterprise ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Dedykowane zasoby CPU</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=ultimate">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="modpacks" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {/* Modpack Basic Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Modpack Basic</h3>
                    <p className="text-sm text-muted-foreground">Dla małych paczek modów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      14.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>10 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Forge/Fabric</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: Polska</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=modpack-basic">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Modpack Standard Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Modpack Standard</h3>
                    <p className="text-sm text-muted-foreground">Dla średnich paczek modów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      24.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>6GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>20 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Forge/Fabric/FTB</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=modpack-standard">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Modpack Premium Plan - Highlighted */}
              <Card className="flex flex-col border-2 border-primary relative">
                <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Polecany
                </div>
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Modpack Premium</h3>
                    <p className="text-sm text-muted-foreground">Dla dużych paczek modów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      39.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>10GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>40 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Wszystkie platformy modów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE/NL</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=modpack-premium">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Modpack Ultimate Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">Modpack Ultimate</h3>
                    <p className="text-sm text-muted-foreground">Dla największych paczek modów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      59.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>16GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Bez limitu slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Wszystkie platformy modów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Dedykowane zasoby CPU</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=modpack-ultimate">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="vps" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {/* VPS Basic Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">VPS Basic</h3>
                    <p className="text-sm text-muted-foreground">Dla małych projektów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      29.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>2 vCPU</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>50GB SSD NVMe</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: Polska</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=vps-basic">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* VPS Premium Plan - Highlighted */}
              <Card className="flex flex-col border-2 border-primary relative">
                <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Polecany
                </div>
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">VPS Premium</h3>
                    <p className="text-sm text-muted-foreground">Dla średnich projektów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      49.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4 vCPU</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>8GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>100GB SSD NVMe</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=vps-premium">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* VPS Ultimate Plan */}
              <Card className="flex flex-col border-2">
                <CardContent className="flex flex-1 flex-col p-6">
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">VPS Ultimate</h3>
                    <p className="text-sm text-muted-foreground">Dla dużych projektów</p>
                  </div>
                  <div className="mt-6 space-y-4">
                    <div className="text-3xl font-bold">
                      79.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>8 vCPU</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>16GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>200GB SSD NVMe</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE/NL</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-auto pt-6">
                    <Button className="w-full" asChild>
                      <Link href="/zamow?plan=vps-ultimate">Zamów Teraz</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </section>

      <section className="bg-muted py-12 md:py-16 lg:py-20">
        <div className="container space-y-6">
          <div className="text-center">
            <Badge variant="outline" className="mb-2">
              Porównanie Planów
            </Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Szczegółowe porównanie planów</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
              Porównaj wszystkie funkcje i wybierz plan, który najlepiej odpowiada Twoim potrzebom.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="p-4 text-left">Funkcja</th>
                  <th className="p-4 text-center">Basic</th>
                  <th className="p-4 text-center">Standard</th>
                  <th className="p-4 text-center">Premium</th>
                  <th className="p-4 text-center">Ultimate</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="p-4 font-medium">RAM</td>
                  <td className="p-4 text-center">2GB</td>
                  <td className="p-4 text-center">4GB</td>
                  <td className="p-4 text-center">8GB</td>
                  <td className="p-4 text-center">16GB</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Sloty</td>
                  <td className="p-4 text-center">10</td>
                  <td className="p-4 text-center">20</td>
                  <td className="p-4 text-center">40</td>
                  <td className="p-4 text-center">Bez limitu</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Przestrzeń dyskowa</td>
                  <td className="p-4 text-center">10GB</td>
                  <td className="p-4 text-center">20GB</td>
                  <td className="p-4 text-center">40GB</td>
                  <td className="p-4 text-center">100GB</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Ochrona DDoS</td>
                  <td className="p-4 text-center">Podstawowa</td>
                  <td className="p-4 text-center">Zaawansowana</td>
                  <td className="p-4 text-center">Premium</td>
                  <td className="p-4 text-center">Enterprise</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Lokalizacje</td>
                  <td className="p-4 text-center">PL</td>
                  <td className="p-4 text-center">PL/DE</td>
                  <td className="p-4 text-center">PL/DE/NL</td>
                  <td className="p-4 text-center">PL/DE/NL</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Kopie zapasowe</td>
                  <td className="p-4 text-center">1</td>
                  <td className="p-4 text-center">3</td>
                  <td className="p-4 text-center">5</td>
                  <td className="p-4 text-center">10</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Wsparcie</td>
                  <td className="p-4 text-center">Email</td>
                  <td className="p-4 text-center">Email, Discord</td>
                  <td className="p-4 text-center">Email, Discord, Telefon</td>
                  <td className="p-4 text-center">Priorytetowe</td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Subdomena</td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Własna domena</td>
                  <td className="p-4 text-center">
                    <HelpCircle className="mx-auto h-5 w-5 text-muted-foreground" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="p-4 font-medium">Dedykowane IP</td>
                  <td className="p-4 text-center">
                    <HelpCircle className="mx-auto h-5 w-5 text-muted-foreground" />
                  </td>
                  <td className="p-4 text-center">
                    <HelpCircle className="mx-auto h-5 w-5 text-muted-foreground" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                  <td className="p-4 text-center">
                    <CheckCircle className="mx-auto h-5 w-5 text-primary" />
                  </td>
                </tr>
                <tr>
                  <td className="p-4"></td>
                  <td className="p-4 text-center">
                    <Button asChild>
                      <Link href="/zamow?plan=basic">Zamów</Link>
                    </Button>
                  </td>
                  <td className="p-4 text-center">
                    <Button asChild>
                      <Link href="/zamow?plan=standard">Zamów</Link>
                    </Button>
                  </td>
                  <td className="p-4 text-center">
                    <Button asChild>
                      <Link href="/zamow?plan=premium">Zamów</Link>
                    </Button>
                  </td>
                  <td className="p-4 text-center">
                    <Button asChild>
                      <Link href="/zamow?plan=ultimate">Zamów</Link>
                    </Button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            FAQ
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Często zadawane pytania</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Odpowiedzi na najczęściej zadawane pytania dotyczące naszych planów hostingowych.
          </p>
        </div>

        <div className="mx-auto max-w-3xl space-y-4">
          <div className="rounded-lg border p-4">
            <h3 className="text-lg font-bold">Jak wybrać odpowiedni plan?</h3>
            <p className="mt-2 text-muted-foreground">
              Wybór planu zależy od liczby graczy, używanych pluginów i modów. Dla małych serwerów dla przyjaciół
              wystarczy plan Basic. Dla serwerów z większą liczbą graczy i pluginów zalecamy plan Standard lub Premium.
              Dla dużych serwerów z modami najlepszy będzie plan Ultimate.
            </p>
          </div>

          <div className="rounded-lg border p-4">
            <h3 className="text-lg font-bold">Czy mogę zmienić plan w przyszłości?</h3>
            <p className="mt-2 text-muted-foreground">
              Tak, możesz w każdej chwili zmienić plan na wyższy lub niższy. Zmiana na wyższy plan jest natychmiastowa,
              a zmiana na niższy plan zostanie uwzględniona przy następnym odnowieniu.
            </p>
          </div>

          <div className="rounded-lg border p-4">
            <h3 className="text-lg font-bold">Jakie metody płatności akceptujecie?</h3>
            <p className="mt-2 text-muted-foreground">
              Akceptujemy płatności kartą kredytową, przelewem bankowym, BLIK, PayPal oraz popularnymi systemami
              płatności online jak Przelewy24, DotPay i PayU.
            </p>
          </div>

          <div className="rounded-lg border p-4">
            <h3 className="text-lg font-bold">Czy oferujecie okres próbny?</h3>
            <p className="mt-2 text-muted-foreground">
              Nie oferujemy okresu próbnego, ale mamy 14-dniową gwarancję zwrotu pieniędzy, jeśli nie będziesz
              zadowolony z naszych usług.
            </p>
          </div>

          <div className="rounded-lg border p-4">
            <h3 className="text-lg font-bold">Jak działa ochrona DDoS?</h3>
            <p className="mt-2 text-muted-foreground">
              Wszystkie nasze serwery są chronione przed atakami DDoS. Używamy zaawansowanych systemów filtrowania
              ruchu, które wykrywają i blokują ataki, zapewniając ciągłość działania Twojego serwera.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-primary text-primary-foreground">
        <div className="container py-12 md:py-16 lg:py-20">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
              Gotowy na własny serwer Minecraft?
            </h2>
            <p className="mt-4 text-lg md:text-xl">
              Wybierz plan, który najlepiej odpowiada Twoim potrzebom i uruchom swój serwer już dziś!
            </p>
            <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/zamow">Zamów Teraz</Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent" asChild>
                <Link href="/kontakt">Masz pytania? Skontaktuj się z nami</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
