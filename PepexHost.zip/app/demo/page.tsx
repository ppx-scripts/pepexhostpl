import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"

export default function DemoPage() {
  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Panel Klienta
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Panel Pterodactyl</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Poznaj nasz nowoczesny panel zarządzania serwerem Minecraft. Pełna kontrola nad serwerem, dostęp do konsoli,
            zarządzanie plikami i wiele więcej.
          </p>
        </div>

        <div className="mx-auto max-w-5xl">
          <div className="rounded-lg border bg-card p-2 shadow-sm">
            <Image
              src="/panel-dashboard.png"
              alt="Panel Pterodactyl"
              width={1200}
              height={800}
              className="rounded-md object-cover"
            />
          </div>
        </div>
      </section>

      <section className="container space-y-12">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-4">
            <TabsTrigger value="dashboard">Pulpit</TabsTrigger>
            <TabsTrigger value="console">Konsola</TabsTrigger>
            <TabsTrigger value="files">Pliki</TabsTrigger>
            <TabsTrigger value="settings">Ustawienia</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <h3 className="text-2xl font-bold">Pulpit Główny</h3>
                <p className="text-muted-foreground">
                  Pulpit główny panelu Pterodactyl zapewnia szybki dostęp do wszystkich funkcji zarządzania serwerem.
                  Monitoruj wykorzystanie zasobów, status serwera i szybko uruchamiaj lub zatrzymuj serwer.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      1
                    </span>
                    <span>Monitorowanie zasobów w czasie rzeczywistym</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      2
                    </span>
                    <span>Szybkie uruchamianie i zatrzymywanie serwera</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      3
                    </span>
                    <span>Podgląd aktywności serwera</span>
                  </li>
                </ul>
              </div>
              <div className="rounded-lg border bg-card p-2 shadow-sm">
                <Image
                  src="/panel-dashboard.png"
                  alt="Pulpit Pterodactyl"
                  width={800}
                  height={600}
                  className="rounded-md object-cover"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="console" className="mt-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <h3 className="text-2xl font-bold">Konsola Serwera</h3>
                <p className="text-muted-foreground">
                  Konsola serwera umożliwia monitorowanie logów serwera w czasie rzeczywistym oraz wykonywanie komend
                  administracyjnych. Pełna kontrola nad serwerem z poziomu przeglądarki.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      1
                    </span>
                    <span>Logi serwera w czasie rzeczywistym</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      2
                    </span>
                    <span>Wykonywanie komend administracyjnych</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      3
                    </span>
                    <span>Historia komend</span>
                  </li>
                </ul>
              </div>
              <div className="rounded-lg border bg-card p-2 shadow-sm">
                <Image
                  src="/panel-console.png"
                  alt="Konsola Pterodactyl"
                  width={800}
                  height={600}
                  className="rounded-md object-cover"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="files" className="mt-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <h3 className="text-2xl font-bold">Zarządzanie Plikami</h3>
                <p className="text-muted-foreground">
                  Zarządzaj plikami serwera bezpośrednio z przeglądarki. Edytuj pliki konfiguracyjne, przesyłaj pluginy
                  i mody, twórz i usuwaj pliki i katalogi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      1
                    </span>
                    <span>Edycja plików konfiguracyjnych</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      2
                    </span>
                    <span>Przesyłanie pluginów i modów</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      3
                    </span>
                    <span>Zarządzanie uprawnieniami</span>
                  </li>
                </ul>
              </div>
              <div className="rounded-lg border bg-card p-2 shadow-sm">
                <Image
                  src="/panel-files.png"
                  alt="Zarządzanie Plikami Pterodactyl"
                  width={800}
                  height={600}
                  className="rounded-md object-cover"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <h3 className="text-2xl font-bold">Ustawienia Serwera</h3>
                <p className="text-muted-foreground">
                  Konfiguruj ustawienia serwera, takie jak wersja Minecraft, limity zasobów, harmonogram zadań i wiele
                  więcej.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      1
                    </span>
                    <span>Zmiana wersji Minecraft</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      2
                    </span>
                    <span>Konfiguracja harmonogramu zadań</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      3
                    </span>
                    <span>Zarządzanie kopiami zapasowymi</span>
                  </li>
                </ul>
              </div>
              <div className="rounded-lg border bg-card p-2 shadow-sm">
                <Image
                  src="/panel-settings.png"
                  alt="Ustawienia Pterodactyl"
                  width={800}
                  height={600}
                  className="rounded-md object-cover"
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </section>

      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Funkcje Panelu
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Kluczowe funkcje panelu</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Poznaj najważniejsze funkcje naszego panelu zarządzania serwerem Minecraft.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">1</span>
              </div>
              <h3 className="text-xl font-bold">Łatwa instalacja pluginów</h3>
              <p className="text-muted-foreground">
                Instaluj pluginy i mody jednym kliknięciem. Wybieraj spośród tysięcy dostępnych pluginów i modów dla
                różnych wersji Minecraft.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">2</span>
              </div>
              <h3 className="text-xl font-bold">Automatyczne kopie zapasowe</h3>
              <p className="text-muted-foreground">
                Twórz automatyczne kopie zapasowe serwera według harmonogramu. Łatwo przywracaj serwer do wcześniejszego
                stanu w przypadku problemów.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">3</span>
              </div>
              <h3 className="text-xl font-bold">Harmonogram zadań</h3>
              <p className="text-muted-foreground">
                Planuj automatyczne restarty, kopie zapasowe, ogłoszenia i inne zadania. Ustaw cykliczne zadania, które
                będą wykonywane automatycznie.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">4</span>
              </div>
              <h3 className="text-xl font-bold">Zarządzanie użytkownikami</h3>
              <p className="text-muted-foreground">
                Dodawaj innych użytkowników do swojego serwera i przydzielaj im odpowiednie uprawnienia. Kontroluj, kto
                ma dostęp do Twojego serwera.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">5</span>
              </div>
              <h3 className="text-xl font-bold">Zmiana wersji Minecraft</h3>
              <p className="text-muted-foreground">
                Łatwo zmieniaj wersję Minecraft jednym kliknięciem. Wspieramy wszystkie wersje od 1.7 do najnowszych, w
                tym snapshoty.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <span className="text-xl font-bold text-primary">6</span>
              </div>
              <h3 className="text-xl font-bold">Integracja z Discord</h3>
              <p className="text-muted-foreground">
                Połącz swój serwer Minecraft z Discordem. Otrzymuj powiadomienia o ważnych wydarzeniach i monitoruj
                status serwera.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="bg-primary text-primary-foreground">
        <div className="container py-12 md:py-16 lg:py-20">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Wypróbuj nasz panel już dziś!</h2>
            <p className="mt-4 text-lg md:text-xl">
              Zamów serwer i przekonaj się, jak łatwe jest zarządzanie serwerem Minecraft z naszym panelem.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/zamow">Zamów Serwer</Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent" asChild>
                <Link href="/kontakt">Masz pytania? Skontaktuj się z nami</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
