import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, AlertCircle, Clock, XCircle } from "lucide-react"

export default function StatusPage() {
  const servers = [
    {
      name: "Serwer PL-01",
      status: "operational",
      uptime: "99.99%",
      location: "Warszawa, Polska",
      lastIncident: "Brak",
    },
    {
      name: "Serwer PL-02",
      status: "operational",
      uptime: "99.98%",
      location: "Kraków, Polska",
      lastIncident: "2025-05-10 (Restart planowy)",
    },
    {
      name: "Serwer DE-01",
      status: "operational",
      uptime: "99.95%",
      location: "Frankfurt, Niemcy",
      lastIncident: "2025-05-05 (Aktualizacja oprogramowania)",
    },
    {
      name: "Serwer DE-02",
      status: "maintenance",
      uptime: "99.90%",
      location: "Berlin, Niemcy",
      lastIncident: "Trwa konserwacja (Planowane zakończenie: 2025-05-20 22:00)",
    },
    {
      name: "Serwer NL-01",
      status: "operational",
      uptime: "99.97%",
      location: "Amsterdam, Holandia",
      lastIncident: "2025-04-28 (Problemy z siecią)",
    },
    {
      name: "Panel Klienta",
      status: "operational",
      uptime: "99.99%",
      location: "Wszystkie lokalizacje",
      lastIncident: "Brak",
    },
    {
      name: "System Płatności",
      status: "operational",
      uptime: "100%",
      location: "Wszystkie lokalizacje",
      lastIncident: "Brak",
    },
    {
      name: "API",
      status: "degraded",
      uptime: "99.80%",
      location: "Wszystkie lokalizacje",
      lastIncident: "Trwają problemy z wydajnością (Rozwiązywane)",
    },
  ]

  const incidents = [
    {
      date: "2025-05-18",
      title: "Problemy z wydajnością API",
      status: "investigating",
      description:
        "Zauważyliśmy problemy z wydajnością API. Nasz zespół techniczny pracuje nad rozwiązaniem problemu. Aktualizacja: Zidentyfikowaliśmy przyczynę problemu i pracujemy nad jego rozwiązaniem.",
      affected: ["API"],
    },
    {
      date: "2025-05-15",
      title: "Planowana konserwacja serwera DE-02",
      status: "scheduled",
      description:
        "Planowana konserwacja serwera DE-02 w celu aktualizacji oprogramowania i zwiększenia wydajności. Konserwacja potrwa od 2025-05-15 22:00 do 2025-05-20 22:00.",
      affected: ["Serwer DE-02"],
    },
    {
      date: "2025-05-05",
      title: "Aktualizacja oprogramowania na serwerze DE-01",
      status: "resolved",
      description:
        "Przeprowadziliśmy aktualizację oprogramowania na serwerze DE-01. Aktualizacja przebiegła pomyślnie, ale wystąpiły krótkie przerwy w działaniu niektórych usług.",
      affected: ["Serwer DE-01"],
    },
    {
      date: "2025-04-28",
      title: "Problemy z siecią na serwerze NL-01",
      status: "resolved",
      description:
        "Wystąpiły problemy z siecią na serwerze NL-01. Problem został rozwiązany, a usługi działają normalnie.",
      affected: ["Serwer NL-01"],
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "operational":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "degraded":
        return <AlertCircle className="h-5 w-5 text-yellow-500" />
      case "maintenance":
        return <Clock className="h-5 w-5 text-blue-500" />
      case "outage":
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return <CheckCircle className="h-5 w-5 text-green-500" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "operational":
        return "Działa"
      case "degraded":
        return "Obniżona wydajność"
      case "maintenance":
        return "Konserwacja"
      case "outage":
        return "Awaria"
      default:
        return "Działa"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "operational":
        return <Badge className="bg-green-500">Działa</Badge>
      case "degraded":
        return <Badge className="bg-yellow-500">Obniżona wydajność</Badge>
      case "maintenance":
        return <Badge className="bg-blue-500">Konserwacja</Badge>
      case "outage":
        return <Badge className="bg-red-500">Awaria</Badge>
      case "investigating":
        return <Badge className="bg-yellow-500">Badanie</Badge>
      case "scheduled":
        return <Badge className="bg-blue-500">Zaplanowane</Badge>
      case "resolved":
        return <Badge className="bg-green-500">Rozwiązane</Badge>
      default:
        return <Badge className="bg-green-500">Działa</Badge>
    }
  }

  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Status Usług
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Status Naszych Usług</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Monitoruj status naszych usług w czasie rzeczywistym. Sprawdź, czy wszystkie systemy działają prawidłowo.
          </p>
        </div>

        <div className="mx-auto max-w-5xl">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Status Systemów</span>
                <span className="text-sm font-normal">Ostatnia aktualizacja: {new Date().toLocaleString("pl-PL")}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {servers.map((server, index) => (
                  <div key={index} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(server.status)}
                      <span className="font-medium">{server.name}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-muted-foreground hidden md:inline-block">
                        Uptime: {server.uptime}
                      </span>
                      <span className="text-sm text-muted-foreground hidden lg:inline-block">
                        Lokalizacja: {server.location}
                      </span>
                      {getStatusBadge(server.status)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Historia Incydentów
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Historia Incydentów</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Sprawdź historię incydentów i planowanych prac konserwacyjnych.
          </p>
        </div>

        <div className="mx-auto max-w-5xl">
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-4">
              <TabsTrigger value="all">Wszystkie</TabsTrigger>
              <TabsTrigger value="active">Aktywne</TabsTrigger>
              <TabsTrigger value="scheduled">Zaplanowane</TabsTrigger>
              <TabsTrigger value="resolved">Rozwiązane</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="space-y-4">
                {incidents.map((incident, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span>{incident.title}</span>
                          {getStatusBadge(incident.status)}
                        </div>
                        <span className="text-sm font-normal">{incident.date}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{incident.description}</p>
                      <div className="mt-4">
                        <span className="text-sm font-medium">Dotknięte systemy:</span>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {incident.affected.map((system, i) => (
                            <Badge key={i} variant="outline">
                              {system}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="active" className="mt-6">
              <div className="space-y-4">
                {incidents
                  .filter((incident) => incident.status === "investigating" || incident.status === "scheduled")
                  .map((incident, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span>{incident.title}</span>
                            {getStatusBadge(incident.status)}
                          </div>
                          <span className="text-sm font-normal">{incident.date}</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{incident.description}</p>
                        <div className="mt-4">
                          <span className="text-sm font-medium">Dotknięte systemy:</span>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {incident.affected.map((system, i) => (
                              <Badge key={i} variant="outline">
                                {system}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="scheduled" className="mt-6">
              <div className="space-y-4">
                {incidents
                  .filter((incident) => incident.status === "scheduled")
                  .map((incident, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span>{incident.title}</span>
                            {getStatusBadge(incident.status)}
                          </div>
                          <span className="text-sm font-normal">{incident.date}</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{incident.description}</p>
                        <div className="mt-4">
                          <span className="text-sm font-medium">Dotknięte systemy:</span>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {incident.affected.map((system, i) => (
                              <Badge key={i} variant="outline">
                                {system}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="resolved" className="mt-6">
              <div className="space-y-4">
                {incidents
                  .filter((incident) => incident.status === "resolved")
                  .map((incident, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span>{incident.title}</span>
                            {getStatusBadge(incident.status)}
                          </div>
                          <span className="text-sm font-normal">{incident.date}</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{incident.description}</p>
                        <div className="mt-4">
                          <span className="text-sm font-medium">Dotknięte systemy:</span>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {incident.affected.map((system, i) => (
                              <Badge key={i} variant="outline">
                                {system}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}
