import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"

export default function ZamowPage() {
  return (
    <div className="flex flex-col gap-16 py-16">
      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Zamówienie
          </Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Zamów Serwer Minecraft</h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Wybierz plan, który najlepiej odpowiada Twoim potrzebom i uruchom swój serwer Minecraft już dziś!
          </p>
        </div>

        <div className="mx-auto max-w-6xl">
          <Tabs defaultValue="minecraft" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
              <TabsTrigger value="minecraft">Minecraft</TabsTrigger>
              <TabsTrigger value="modpacks">Modpacks</TabsTrigger>
              <TabsTrigger value="vps">VPS</TabsTrigger>
            </TabsList>

            <TabsContent value="minecraft" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                {/* Basic Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>Basic</CardTitle>
                    <p className="text-sm text-muted-foreground">Idealny dla małych serwerów</p>
                    <div className="mt-4 text-3xl font-bold">
                      9.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>2GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>10 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Podstawowa ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: Polska</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>

                {/* Standard Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>Standard</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla średnich serwerów</p>
                    <div className="mt-4 text-3xl font-bold">
                      19.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>20 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Zaawansowana ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>

                {/* Premium Plan - Highlighted */}
                <Card className="flex flex-col border-2 border-primary relative">
                  <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                    Polecany
                  </div>
                  <CardHeader>
                    <CardTitle>Premium</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla dużych serwerów</p>
                    <div className="mt-4 text-3xl font-bold">
                      29.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>8GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>40 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Premium ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE/NL</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Wybierz</Button>
                  </CardFooter>
                </Card>

                {/* Ultimate Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>Ultimate</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla profesjonalnych projektów</p>
                    <div className="mt-4 text-3xl font-bold">
                      49.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>16GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Bez limitu slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Enterprise ochrona DDoS</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Dedykowane zasoby CPU</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="modpacks" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                {/* Modpack Basic Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>Modpack Basic</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla małych paczek modów</p>
                    <div className="mt-4 text-3xl font-bold">
                      14.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>10 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Forge/Fabric</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: Polska</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>

                {/* Modpack Standard Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>Modpack Standard</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla średnich paczek modów</p>
                    <div className="mt-4 text-3xl font-bold">
                      24.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>6GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>20 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Forge/Fabric/FTB</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>

                {/* Modpack Premium Plan - Highlighted */}
                <Card className="flex flex-col border-2 border-primary relative">
                  <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                    Polecany
                  </div>
                  <CardHeader>
                    <CardTitle>Modpack Premium</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla dużych paczek modów</p>
                    <div className="mt-4 text-3xl font-bold">
                      39.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>10GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>40 Slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Wszystkie platformy modów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE/NL</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Wybierz</Button>
                  </CardFooter>
                </Card>

                {/* Modpack Ultimate Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>Modpack Ultimate</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla największych paczek modów</p>
                    <div className="mt-4 text-3xl font-bold">
                      59.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>16GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Bez limitu slotów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Wszystkie platformy modów</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Dedykowane zasoby CPU</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="vps" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {/* VPS Basic Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>VPS Basic</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla małych projektów</p>
                    <div className="mt-4 text-3xl font-bold">
                      29.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>2 vCPU</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>50GB SSD NVMe</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: Polska</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>

                {/* VPS Premium Plan - Highlighted */}
                <Card className="flex flex-col border-2 border-primary relative">
                  <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                    Polecany
                  </div>
                  <CardHeader>
                    <CardTitle>VPS Premium</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla średnich projektów</p>
                    <div className="mt-4 text-3xl font-bold">
                      49.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>4 vCPU</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>8GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>100GB SSD NVMe</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Wybierz</Button>
                  </CardFooter>
                </Card>

                {/* VPS Ultimate Plan */}
                <Card className="flex flex-col border-2">
                  <CardHeader>
                    <CardTitle>VPS Ultimate</CardTitle>
                    <p className="text-sm text-muted-foreground">Dla dużych projektów</p>
                    <div className="mt-4 text-3xl font-bold">
                      79.99 zł<span className="text-sm font-normal text-muted-foreground">/mies.</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>8 vCPU</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>16GB RAM</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>200GB SSD NVMe</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-2 h-4 w-4 text-primary" />
                        <span>Lokalizacja: PL/DE/NL</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" variant="outline">
                      Wybierz
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <section className="container space-y-6">
        <div className="text-center">
          <Badge variant="outline" className="mb-2">
            Konfiguracja
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Skonfiguruj swój serwer</h2>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground">
            Dostosuj swój serwer do swoich potrzeb. Wybierz wersję Minecraft, lokalizację i dodatkowe opcje.
          </p>
        </div>

        <div className="mx-auto max-w-3xl">
          <Card>
            <CardHeader>
              <CardTitle>Konfiguracja serwera</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="server-name">Nazwa serwera</Label>
                <Input id="server-name" placeholder="Mój serwer Minecraft" />
              </div>

              <div className="space-y-2">
                <Label>Wersja Minecraft</Label>
                <Select defaultValue="1.20.4">
                  <SelectTrigger>
                    <SelectValue placeholder="Wybierz wersję" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1.20.4">Minecraft 1.20.4</SelectItem>
                    <SelectItem value="1.19.4">Minecraft 1.19.4</SelectItem>
                    <SelectItem value="1.18.2">Minecraft 1.18.2</SelectItem>
                    <SelectItem value="1.17.1">Minecraft 1.17.1</SelectItem>
                    <SelectItem value="1.16.5">Minecraft 1.16.5</SelectItem>
                    <SelectItem value="1.12.2">Minecraft 1.12.2</SelectItem>
                    <SelectItem value="1.8.9">Minecraft 1.8.9</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Silnik serwera</Label>
                <Select defaultValue="paper">
                  <SelectTrigger>
                    <SelectValue placeholder="Wybierz silnik" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vanilla">Vanilla</SelectItem>
                    <SelectItem value="paper">Paper</SelectItem>
                    <SelectItem value="spigot">Spigot</SelectItem>
                    <SelectItem value="forge">Forge</SelectItem>
                    <SelectItem value="fabric">Fabric</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Lokalizacja serwera</Label>
                <RadioGroup defaultValue="pl">
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="pl" id="pl" />
                      <Label htmlFor="pl">Polska (Warszawa)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="de" id="de" />
                      <Label htmlFor="de">Niemcy (Frankfurt)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="nl" id="nl" />
                      <Label htmlFor="nl">Holandia (Amsterdam)</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Dodatkowe opcje</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="backup" className="h-4 w-4 rounded border-gray-300" />
                    <Label htmlFor="backup">Automatyczne kopie zapasowe (+5 zł/mies.)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="ddos" className="h-4 w-4 rounded border-gray-300" />
                    <Label htmlFor="ddos">Zaawansowana ochrona DDoS (+10 zł/mies.)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="domain" className="h-4 w-4 rounded border-gray-300" />
                    <Label htmlFor="domain">Własna domena (+15 zł/rok)</Label>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" asChild>
                <Link href="/oferta">Wróć do oferty</Link>
              </Button>
              <Button>Przejdź do płatności</Button>
            </CardFooter>
          </Card>
        </div>
      </section>
    </div>
  )
}
